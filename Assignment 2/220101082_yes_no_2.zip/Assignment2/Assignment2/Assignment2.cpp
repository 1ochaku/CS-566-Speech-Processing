
#include "stdafx.h"
#include <iostream>
#include <Windows.h>

using namespace std;
#pragma comment(lib, "winmm.lib")
short int waveIn[16025 * 3];
void processSpeech(LPSTR lpData, DWORD dwBufferLength);
void StartRecord();

int _tmain(int argc, _TCHAR* argv[])
{
	StartRecord();
    return 0;
}  

void StartRecord()
{
 const int NUMPTS = 16025 * 3;   // 3 seconds
 int sampleRate = 16025; 
 int i;
 // 'short int' is a 16-bit type; I request 16-bit samples below
                         // for 8-bit capture, you'd use 'unsigned char' or 'BYTE' 8-bit     types
 HWAVEIN      hWaveIn;
 MMRESULT result;
 WAVEFORMATEX pFormat;
 pFormat.wFormatTag=WAVE_FORMAT_PCM;     // simple, uncompressed format
 pFormat.nChannels=1;                    //  1=mono, 2=stereo
 pFormat.nSamplesPerSec=sampleRate;      // 8.0 kHz, 11.025 kHz, 22.05 kHz, and 44.1 kHz
 pFormat.nAvgBytesPerSec=sampleRate*2;   // =  nSamplesPerSec � nBlockAlign
 pFormat.nBlockAlign=2;                  // = (nChannels � wBitsPerSample) / 8
 pFormat.wBitsPerSample=16;              //  16 for high quality, 8 for telephone-grade
 pFormat.cbSize=0;
 // Specify recording parameters
 result = waveInOpen(&hWaveIn, WAVE_MAPPER,&pFormat, 0L, 0L, WAVE_FORMAT_DIRECT);
 WAVEHDR      WaveInHdr;
 // Set up and prepare header for input
 WaveInHdr.lpData = (LPSTR)waveIn;
 WaveInHdr.dwBufferLength = NUMPTS*2;
 WaveInHdr.dwBytesRecorded=0;
 WaveInHdr.dwUser = 0L;
 WaveInHdr.dwFlags = 0L;
 WaveInHdr.dwLoops = 0L;
 waveInPrepareHeader(hWaveIn, &WaveInHdr, sizeof(WAVEHDR));
 // Insert a wave input buffer
 result = waveInAddBuffer(hWaveIn, &WaveInHdr, sizeof(WAVEHDR));
 // Commence sampling input
 result = waveInStart(hWaveIn);
 cout << "recording for 3 seconds..." << endl;
 Sleep(3 * 1000);
 // Wait until finished recording
 waveInClose(hWaveIn);
 // processing the recorded speech
 processSpeech((LPSTR)waveIn,NUMPTS*2);
}

void processSpeech(LPSTR lpData, DWORD dwBufferLength) {
	short* arr = (short*)lpData;
	int x,i = 0;
	int size = dwBufferLength / sizeof(short);
	int frameSize = 400, frameShift = frameSize/2;
	int nf, j = 0, ifYes = 0;
	int energyArray[20000] = {0}, zcrArray[20000] = {0}, zcrThreshold = 25;
	int maxEnergy = 0, energyThreshold;
	i = 0;
	nf = 0;

	// calculating the energy per frame
	while(i+frameSize<size) {
		energyArray[nf] = 0;
		for(j = i; j<i+frameSize; j++) {
			energyArray[nf] += arr[j]*arr[j]; 
		}
		// printf("%d\n",energyArray[nf]);
		i += frameShift;
		nf++;
	}

	// finding the max energy to set threshold
	for(i = 0; i<nf; i++) {
		if(energyArray[i]>maxEnergy) maxEnergy = energyArray[i];
	}

	// this serves to distinguish between noise and actual word
	energyThreshold = maxEnergy/5;

	i = 0;
	nf = 0;

	// calculating the zcr
	while(i+frameSize<size) {
		zcrArray[nf] = 0;
		for(j = i+1; j<i+frameSize; j++) {
			if((arr[j-1]<=0 && arr[j]>0) || (arr[j-1]>=0 && arr[j]<0)) zcrArray[nf]++; 
		}
		// printf("%d\n",zcrArray[nf]);
		i += frameShift;
		nf++;
	}

	// checking for adjacent frames if there is a sudden spike in zcr
	for(i = 1; i<nf; i++) {
		if(energyArray[i] > energyThreshold &&
			zcrArray[i]-zcrArray[i-1] > zcrThreshold) {
			ifYes = 1;
			break;
		}
	}

	// based on above analysis outputting if yes or no
	if(ifYes) {
		printf("\n Yes \n");
		printf("\n Press enter to continue");
		getchar();
	}else {
		printf("\n No \n");
		printf("\n Press enter to continue");
		getchar();
	}
}