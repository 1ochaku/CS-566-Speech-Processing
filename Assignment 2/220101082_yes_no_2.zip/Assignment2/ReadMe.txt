- How to run the file:
1. Open the project (that is, 220101082_yes_no_2\Assignment2\Assignment2\Assignment2.vcxproj) in VS2010.
3. Press F5 for building your solution and running it.
4. The console pops up and displays the message, "recording for 3 seconds ...", at that time, either yes or no has to be spoken.

- What is the code logic?
1. After analysing some samples, it was observed that ZCR value for yes spikes suddenly at the end, this served as the basis for differentiating the audio from yes or no.
2. First the ASCII values are read from the recorded input array.
3. Since we had to compute the energy and ZCR values, so I assumed a frame size of 400 and a frame shift of (frame size)/2 for computing the values. As if we don't consider overlap between the frames, there is a possibility the answer is not correct.
4. Next, the ZCR values are traversed and adjacent values are compared if it is greater than ZCR Threshold then it prints Yes else No. 
5. Here since the input audio is directly processed so it might have the initial or ending noise/silence so to identify that I used energy threshold as 20% of the maximum energy observed and for the frames having more than energy threshold, the ZCR value comparison, as pointed in 4th point was considered.
