 

#include "stdafx.h"
#include "stdio.h"
#include "process.h"

int _tmain(int argc, _TCHAR* argv[])
{
	int x,i = 0;
	int arr[50000] = {0};
	int size;
	int err;
	int frameSize = 400, frameShift = frameSize/2;
	int nf, j = 0, ifYes = 0;
	int energyArray[20000] = {0}, zcrArray[20000] = {0}, zcrThreshold = 30;
	
	// file handling as given
	FILE *f1 = NULL;
	err = fopen_s(&f1 , "yes.txt" , "r");
	if (err !=NULL){
		printf( "\n Cannot Open");
		// To handle the file openning error
		/*
		printf("\n Press enter to continue");
		getchar();
		*/
		exit(1);
	}
	// reading the input file
	while(!feof(f1)){
		if (fscanf_s(f1 , "%d" , &x) == 1){
			// printf("%d\n" , x);
			arr[i] = x;
			i++;
		}
	}
	fclose(f1);
	size = i;
	i = 0;
	nf = 0;

	// calculating the energy per frame
	while(i+frameSize<size) {
		energyArray[nf] = 0;
		for(j = i; j<i+frameSize; j++) {
			energyArray[nf] += arr[j]*arr[j]; 
		}
		// printf("%d\n",energyArray[nf]);
		i += frameShift;
		nf++;
	}

	i = 0;
	nf = 0;

	// calculating the zcr
	while(i+frameSize<size) {
		zcrArray[nf] = 0;
		for(j = i+1; j<i+frameSize; j++) {
			if((arr[j-1]<=0 && arr[j]>0) || (arr[j-1]>=0 && arr[j]<0)) zcrArray[nf]++; 
		}
		// printf("%d\n",zcrArray[nf]);
		i += frameShift;
		nf++;
	}

	// checking for adjacent frames if there is a sudden spike in zcr
	for(i = 1; i<nf; i++) {
		if(zcrArray[i]-zcrArray[i-1] > zcrThreshold) {
			ifYes = 1;
			break;
		}
	}

	// based on above analysis outputting if yes or no
	if(ifYes) {
		printf("\n Yes \n");
		printf("\n Press enter to continue");
		getchar();
	}else {
		printf("\n No \n");
		printf("\n Press enter to continue");
		getchar();
	}

	return 0;
}

