- How to run the file:
1. Save your input file in the Assignment Folder.
2. Open the project (that is, 220101082_yes_no\Assignment1\Assignment1\Assignment1.vcxproj) in VS2010, and in the Source Files/Assignment.cpp file, in line no 16, where input file name has to be written, replace it with your input file name.
3. Press F5 for building your solution and running it.
4. After the code processes the file, it outputs yes or no depending upon the input file.

- What should be the input file format?
1. Make sure the input file has only the segmented word containing only the word.
2. There should be no noise/silence at the beginning or end of the file.
3. Otherwise results can vary.

- What is the code logic?
1. After analysing some samples, it was observed that ZCR value for yes spikes suddenly at the end, this served as the basis for differentiating the audio from yes or no.
2. First the ASCII values are read from the input file.
3. Since we had to compute the energy and ZCR values, so I assumed a frame size of 400 and a frame shift of (frame size)/2 for computing the values. As if we don't consider overlap between the frames, there is a possibility the answer is not correct.
4. Next, the ZCR values are traversed and adjacent values are compared if it greater than ZCR Threshold then it prints Yes else No. 

- Files Added for Testing
1. I have added multiple files for testing in "220101082_yes_no\Assignment1\Assignment1\" folder.
2. Make sure that when you add a new file for testing, it should be in the same folder and there is no noise/silence at the beginning or end of the spoken word that is yes or no.